package com.example.quranplayer;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.IOException;

public class MainActivity extends Activity {

    MediaPlayer mediaPlayer;
    Handler handler = new Handler();

    String[] playlist = {
            "/storage/emulated/0/Quran/012.mp3",
            "/storage/emulated/0/Quran/018.mp3",
            "/storage/emulated/0/Quran/019.mp3"
    };

    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView text = new TextView(this);
        text.setText("Quran Auto Player Running");
        text.setTextSize(22f);

        setContentView(text);

        startChecking();
    }

    void startChecking() {

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();

                boolean bluetoothConnected =
                        adapter != null &&
                        adapter.getProfileConnectionState(1) == 2;

                boolean screenOff =
                        !((WindowManager)getSystemService(WINDOW_SERVICE))
                                .getDefaultDisplay().getState()
                                .equals(2);

                if (bluetoothConnected && screenOff) {

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            playAudio();
                        }
                    }, 60000);

                }

                handler.postDelayed(this, 5000);

            }
        }, 5000);
    }

    void playAudio() {

        try {

            if (mediaPlayer != null) {
                mediaPlayer.release();
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(playlist[currentIndex]);
            mediaPlayer.prepare();
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(mp -> {

                currentIndex++;

                if(currentIndex >= playlist.length){
                    currentIndex = 0;
                }

                playAudio();

            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
